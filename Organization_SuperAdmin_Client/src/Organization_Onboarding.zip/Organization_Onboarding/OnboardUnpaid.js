import React, { useState, useEffect } from 'react';
import '@fontsource/inter';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Table } from 'react-bootstrap';
import './OnboardUnpaid.css';
import actionIcon from '../assest/actionbutton.png';
import { useNavigate } from 'react-router-dom';
import image from './defimg.png';

const ITEMS_PER_PAGE = 10;

const App = () => {
  const navigate = useNavigate();
  const [onboardunpaiding, setonboardunpaiding] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    fetchonboardunpaiding(); // Fetch data on component mount
  }, []);


    const fetchonboardunpaiding = async () => {
      try {
        const response = await fetch(`http://localhost:5000/superAdmin_onboarding_organizations`);
        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.message || 'Failed to fetch data');
        }
        const data = await response.json();
        setonboardunpaiding(data.organizations);
      } catch (error) {
        console.error('Error fetching onboardunpaiding_Organization:', error.message || error);
        // Display an alert or set an error state to inform the user
        // e.g., setErrorState(true);
      }
    };
    

  const totalPages = Math.ceil(onboardunpaiding.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const pagination_onboardunpaiding = onboardunpaiding.slice(startIndex, endIndex);

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    const maxVisiblePages = 5;
    const ellipsis = "...";
    const totalPages = Math.ceil(onboardunpaiding.length / ITEMS_PER_PAGE);
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    if (startPage > 1) {
      pageNumbers.push(
        <span
          key={1}
          className={`onboardunpaidpagination-page ${
            currentPage === 1 ? "active" : ""
          }`}
          onClick={() => handlePageChange(1)}
        >
          {1}
        </span>
      );
      if (startPage > 2) {
        pageNumbers.push(<span key="ellipsisStart" className="ellipsis">{ellipsis}</span>);
      }
    }

    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(
        <span
          key={i}
          className={`onboardunpaidpagination-page ${
            currentPage === i ? "active" : ""
          }`}
          onClick={() => handlePageChange(i)}
        >
          {i}
        </span>
      );
    }

    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        pageNumbers.push(<span key="ellipsisEnd" className="onboardunpaid-ellipsis">{ellipsis}</span>);
      }
      pageNumbers.push(
        <span
          key={totalPages}
          className={`onboardunpaidpagination-page ${
            currentPage === totalPages ? "active" : ""
          }`}
          onClick={() => handlePageChange(totalPages)}
        >
          {totalPages}
        </span>
      );
    }
    return pageNumbers;
  };

  const newonboardunpaid = () => {
    navigate('/AddOrganization');
  };

  const handleSingleOrganizationClick = (onboardunpaid_id) => {
    console.log('onboardunpaiding ID being passed:', onboardunpaid_id); // Log the ID to console
    navigate('', {
      state: { id: onboardunpaid_id },
    });
  };

  return (
    <div className="container">
     
      <div style={{borderRadius: '20px' }} className="shadow-sm onboardunpaid-table-container">
        <div className="onboardunpaid-header-row">
          <div>
            <h5 style={{ color: '#212121', fontSize: '18px', fontWeight: 'bold' }} className=" mt-3">Unpaid Organization</h5>
            <h6 style={{ fontSize: '13px', color: '#B5B5C3' }} >
              {onboardunpaiding.length} Organization
            </h6>
          </div>
          <button className="add-onboardunpaid-button mt-1" onClick={newonboardunpaid}>
            Send Notification
          </button>
        </div>

        <div className="mt-3 onboardunpaid-table-container-innercell">
          <Table bordered={false} className="table-borderless onboardunpaid-table-border" >
            <thead style={{ borderRadius: '20px'}}>
              <tr className='onboardunpaidingList-tableRow'>
                <th className='text-center'  style={{ color: '#667085', backgroundColor: '#FAFAFA' ,fontWeight:'400'}}>Name</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA' ,fontWeight:'400' }}>ID</th>
                <th  className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}>Last Purchase</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}>Phone number</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}>Expired Date</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400', whiteSpace:'nowrap' }}>Payment Status</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}></th>
              </tr>
            </thead>
            <tbody>
              {pagination_onboardunpaiding.map((onboardunpaiding, index) => (
                <tr key={index}>
                  <td className="align-middle">
                    <div className="d-flex align-items-center">
                      <img
                        src={onboardunpaiding.profile ? onboardunpaiding.profile : image}
                        width={36}
                        alt="organization"
                        className="rounded-circle me-2"
                      />
                      <div>
                        <div className='onboardunpaiding-table-details'>{onboardunpaiding.organization_name}</div>
                        <div className="text-muted">{onboardunpaiding.organization_type}</div>
                      </div>
                    </div>
                  </td>
                  <td className='text-center onboardunpaiding-table-details' >{onboardunpaiding.id}</td>
                  <td className='text-center onboardunpaiding-table-details' >{onboardunpaiding.email_id}</td>
                  <td className='text-center onboardunpaiding-table-details'>{onboardunpaiding.organization_mobile_no}</td>
                  <td >
                    <div className='text-center onboardunpaiding-table-details'>{onboardunpaiding.Date}</div>
                  </td>
                  <td className='text-center onboardunpaiding-status'>
  <span className="unpaid-pending-status">
        {/* {onboardunpaiding.status} */}pending
      </span></td>
                  <td className="">
                    <button className="onboardunpaid-action-button ms-4" onClick={() => handleSingleOrganizationClick(onboardunpaiding.id)}>
                      <img src={actionIcon} alt="Action" className="onboardunpaid-action-icon" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      </div>
      <div className="onboardunpaid-pagination">
        <span className="onboardunpaid-pagination-arrow" onClick={() => handlePageChange(currentPage - 1)}>
          <span className="onboardunpaid-prevoius-arrow">&#8249;</span> Previous
        </span>
        <span className="onboardunpaid-pagination-pages">{renderPageNumbers()}</span>
        <span className="onboardunpaid-pagination-arrow" onClick={() => handlePageChange(currentPage + 1)}>
          Next <span className="onboardunpaid-next-arrow">&#8250;</span>
        </span>
      </div>
    </div>
  );
};

export default App;
