import React, { useState } from "react";
import { Form, Row, Col, Button, Image } from "react-bootstrap";
import PhoneInput from 'react-phone-input-2';
import "react-phone-input-2/lib/style.css";
import countryList from "react-select-country-list";
import avatar from "../images/defimg.png";
import upload from "../assest/export.png";
import success from "../assest/success.png";
import "./AddOrganization.css";
import { Link, useNavigate, useLocation } from 'react-router-dom';


const AddOrganization = () => {

  const [profile, setProfile] = useState(null);
  const [phoneNumber, setPhoneNumber] = useState("");
  const [orgname, setOrgName] = useState("");
  const [address, setAddress] = useState("");
  const [file, setFile] = useState(null);
  const [errorMessage3, setErrorMessage3] = useState("");
  const [orgemail, setOrgEmail] = useState("");
  const [orgtype, setOrgType] = useState("");
  const [gstNumber, setGstNumber] = useState("");
  const [orgRegNumber, setOrgRegNumber] = useState("");
  const [countStudents, setCountStudents] = useState("");
  const [countStaffs, setCountStaffs] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [pincode, setPincode] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [errorMessage1, setErrorMessage1] = useState("");
  const [formErrors, setFormErrors] = useState({});
  const [RMname, setRMname] = useState("");
  const [RMid, setRMid] = useState("");


  const navigate = useNavigate();

  const handleFileIconClick = () => {
    document.getElementById('fileInput').click();
  };

  const handleFile = (event) => {
    const selectedFile = event.target.files[0];
    const reader = new FileReader();

    const allowedTypes = ['application/pdf', 'image/jpeg', 'image/jpg', 'image/png'];

    if (selectedFile && allowedTypes.includes(selectedFile.type)) {
      reader.onload = () => {
        const base64Data = reader.result;
        if (selectedFile.size <= 2 * 1024 * 1024) { // Check if file size is within 2MB
          setFile(base64Data);
        } else {
          setErrorMessage1("File size exceeds 2MB");
          setFile(null);
        }
      };
      reader.readAsDataURL(selectedFile);
    } else {
      setErrorMessage1("Invalid file type, expected pdf, jpeg, jpg, png");
      setFile(null);
    }
  };

  const handleChange = (value) => {
    setPhoneNumber(value);
  };



  const handleProfilePictureChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setProfile(e.target.result);
      };
      reader.readAsDataURL(event.target.files[0]);

      // Reset the input field value
      event.target.value = null;
    }
  };

  const validatePhoneNumber = (phoneNumber) => {
    // Remove any non-digit characters (optional, depending on your requirements)
    const cleanedPhoneNumber = phoneNumber.replace(/\D/g, '');
    
    // Check if the phone number has at least 10 digits
    if (cleanedPhoneNumber.length < 12) {
      return false; // Phone number is invalid
    }
  
    // Validate the phone number using the pattern
    const phoneNumberPattern = /^\+?[1-9]\d{1,14}$/;
    return phoneNumberPattern.test(phoneNumber);
  };



const checkFields = () => {
  const errors = {};

  if (!orgname) errors.orgname = "Organization Name is required";
  if (!orgtype) errors.orgtype = "Organization Type is required";
  if (!orgemail) errors.orgemail = "Invalid Email ID";
  if (!validatePhoneNumber(phoneNumber)) errors.phoneNumber = "Invalid Phone Number";
  if (!gstNumber) errors.gstNumber = "GST Number is required";
  if (!orgRegNumber) errors.orgRegNumber = "Organization Registration Number is required";
  if (!countStudents) errors.countStudents = "Valid Count of Students is required";
  if (!countStaffs) errors.countStaffs = "Valid Count of Staffs is required";
  if (!address) errors.address = "Address is required";
  if (!state) errors.state = "State is required";
  if (!pincode) errors.pincode = "Invalid Pincode";
  if (!file) errors.file = "Document upload is required";

  setFormErrors(errors);

  if (Object.keys(errors).length === 0) {
    // Proceed with form submission
    console.log("Form submitted successfully");
  }
}

const handleSubmit = async (e) => {
  e.preventDefault();

  try {
   
    const userData = {
      profile:profile,
      organization_name:orgname,
      organization_type:orgtype,
      email_id:orgemail,
      oraganization_mobile_no:phoneNumber,
      address:address,
      state:state,
      pincode:pincode,
      gst_number:gstNumber,
      count_of_student:countStudents,
      count_of_staff:countStaffs,
      organization_register_no:orgRegNumber,
      upload_doc:file,
      city:city,
      RMname:RMname,
      RMid:RMid,
    
    }

  // API call using fetch
  const response = await fetch(`http:localhost:5000/superAdmin_organization_mobilenumber`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(userData)
  });



  // Parsing the JSON response
  const responseData = await response.json();


    // Checking response status
    if (!response.ok) {
      setErrorMessage(responseData.message);
    }
 else{
  alert(responseData.message);
  navigate('/ListOfOnboard_Organization');
 }

} catch (error) {
  console.error('Error:', error);
  setErrorMessage('Network error, Please try again later');
}
};

const handleMailChange = (e) => {
  const verify = e.target.value.toLowerCase();
  setOrgEmail(verify);

  // Validate email
  if (!verify.includes('@') || !verify.includes('.com')) {
    setErrorMessage3('Email must include "@" and ".com"');
  } else {
    setErrorMessage3('');
  }
  }
  const handleFormSubmit = (e) => {
    e.preventDefault();
    checkFields(e);
    if (orgname.trim() && orgtype.trim() && phoneNumber.trim() && orgemail.trim() && gstNumber.trim() 
    && orgRegNumber.trim() && countStudents.trim() && countStaffs.trim() && state.trim()
        && address.trim() && pincode.trim() )
    {
      if (!validatePhoneNumber(phoneNumber)) {
        setErrorMessage('Please enter a valid organization mobile number.');
        return; // Prevent submission if phone number is invalid
      }
    
      if (!file) {
        setErrorMessage('Please upload a document before proceeding.');
        return ;
      }

      handleSubmit(e);
    }

  };

  
  return (
    <div fluid className="addorganization-main-container">
      <div className="row align-items-center mb-4">
        <div className="col-12">
          <h1 className="add-organization-head">Onboarding Organization</h1>
          <hr className="custom-hr" />
        </div>
      </div>

      <div className="addorganization-content-container">
        <div className="row align-items-center">
          <Col md={12}>
            <h3 className="add-organization-head3">Add Organization</h3>
          </Col>
          <hr className="custom-hr1" />
          {errorMessage && <p className="text-danger fs-4 mt-3 mb-n4">{errorMessage}</p>}
        </div>

        <Row className="mt-3">
          <Col md={4} className="image-container text-center">
            <div className="profile-pic">
              <img
                src={profile || avatar}
                alt="Profile"
                className="img-fluid rounded"
              />
              <Button variant="primary" className="upload-button" onClick={() => document.getElementById('profileInput').click()}>
                Upload
              </Button>
              <input
                hidden
                id="profileInput"
                type="file"
                accept="image/*"
                onChange={handleProfilePictureChange}
              />
            </div>
          </Col>

          <Col>
            <Form>
              <Row className="mb-4 mt-3">
                <Form.Group as={Col} md={6} className="mb-3">
                  <Form.Label id="OrgInput" className={formErrors.orgname ? "text-danger" : "text-dark"}>
                    Organization Name*
                  </Form.Label>
                  <Form.Control
                    type="text"
                 
                    className="custom-input"
                    value={orgname}
                    onChange={(e) => setOrgName(e.target.value)}
                  />
                </Form.Group>
                
                <Form.Group as={Col} md={6}>
                  <Form.Label id="orgtype" className={formErrors.orgtype ? "text-danger" : "text-dark"}>
                    Organization Type*
                  </Form.Label>
                  <Form.Select
                    defaultValue="Placeholder"
                    className="custom-select"
                    onChange={(e) => setOrgType(e.target.value)}
                  >
                    <option >Placeholder</option>
                    <option>School</option>
                    <option>College</option>
                    <option>Industry</option>
                  </Form.Select>
                </Form.Group>
              </Row>

              <Row className="mb-4">
                <Form.Group as={Col} md={6} className="mb-3">
                  <Form.Label id="emailInput" className={formErrors.orgemail ? "text-danger" : "text-dark"}>Email-id*</Form.Label>
                  <Form.Control
                    type="email"
                    
                    className="custom-input"
                    value={orgemail}
                    onChange={handleMailChange}
                  />
                   {errorMessage3 && <p className="text-danger fs-6 mt-3 mb-n4">{errorMessage3}</p>}
                </Form.Group>
                <Form.Group as={Col} md={6}>
                  <Form.Label className={formErrors.phoneNumber ? "text-danger" : "text-dark"} id="OrgphoneInput">
                    Organization Mobile Number*
                  </Form.Label>
                  <PhoneInput style={{zIndex:1}}
               
                      containerClass='reg-dummycls reg-mobilephone'
                      className="register-org-phone"
                      country={"in"}

                      value={phoneNumber}
                      onChange={handleChange}
                      inputProps={{
                        required: true,
                      }}
                    />
                </Form.Group>
              </Row>

              <Row className="mb-4">
                <Form.Group as={Col} md={6} className="mb-3">
                  <Form.Label id="gstNumber" className={formErrors.gstNumber ? "text-danger" : "text-dark"}>GST Number*</Form.Label>
                  <Form.Control
                    type="text"
                 
                    className="custom-input"
                    value={gstNumber}
                    // onChange={(e) => setGstNumber(e.target.value)}
                    onChange={(e) => {
      const inputValue = e.target.value;

      // Allow only up to 15 digits
      if (inputValue.length <= 15) {
        setGstNumber(inputValue);
      
      }
    }}
                  />
                </Form.Group>

                <Form.Group as={Col} md={6} >
                  <Form.Label className="text-dark">RM Code</Form.Label>
                  <Form.Control
                    type="text"
                
                    className="custom-input"
                  />
                </Form.Group>
              </Row>
            </Form>
          </Col>
        </Row>

        <Row>
          <Form>
            <Row className="mb-4 mt-2">
              <Form.Group as={Col} md={4} className="mb-3">
                <Form.Label className={formErrors.countStudents ? "text-danger" : "text-dark"}>Count of Students*</Form.Label>
                <Form.Control
                  type="text"
              
                  className="custom-input"
                  value={countStudents}
                  onChange={(e) => {
  const value = e.target.value;
  const digitsOnly = value.replace(/\D/g, ''); // Remove non-digits
  if (digitsOnly.length <= 7) {
    setCountStudents(digitsOnly);
  }
}}
                />
              </Form.Group>
              <Form.Group as={Col} md={4} className="mb-3">
                <Form.Label className={formErrors.orgRegNumber ? "text-danger" : "text-dark"}>Organization Registration Number*</Form.Label>
                <Form.Control
                  type="text"
               
                  className="custom-input"
                  value={orgRegNumber}
                    onChange={(e) => setOrgRegNumber(e.target.value)}
                />
              </Form.Group>
              <Form.Group as={Col} md={4} >
                <label className={formErrors.file ? "text-danger" : "text-dark"} id="fileUpdateInput">
                  Upload Document*
                </label>
                <br />
                <div className="w-100 d-flex">
                  <form className="w-100 upload-file">
                    <input
                      hidden
                      id="fileInput"
                      className={`file-22 ${file ? '' : 'error-border'}`}
                      type="file"
                      name="file"
                      onChange={handleFile}
                      required
                    />
                    <div className="w-100 register-uploadicon-container position-relative">
                      <img
                        src={upload} // Replace with your upload icon
                        onClick={handleFileIconClick}
                        className="register-imagelink-button position-absolute"
                        alt="Upload"
                      />
                      {!file && (
                        <span className="register-placeholder-text" id="fileInput">Upload file</span>
                      )}
                    </div>
                    {file && (
                      <span className="register-image-upload">
                        <span className="register-upload-icon">
                          <img
                            src={success} // Replace with success icon
                            alt="Upload Successfully"
                            className="register-upload-image"
                          />
                        </span>
                        <span className="register-upload-success">Upload Successful</span>
                      </span>
                    )}
                  </form>
                </div>
                {errorMessage1 && <p className="signup-error-message text-danger mt-1 mb-n3">{errorMessage1}</p>}
                <br />
              </Form.Group>
            </Row>

            <Row className="mb-4">
              <Form.Group as={Col} md={4} className="mb-3">
                <Form.Label className={formErrors.countStaffs ? "text-danger" : "text-dark"}>Count of Staffs*</Form.Label>
                <Form.Control
                  type="text"
             
                  className="custom-input"
                  value={countStaffs}
                  onChange={(e) => {
  const value = e.target.value;
  const digitsOnly = value.replace(/\D/g, ''); // Remove non-digits
  if (digitsOnly.length <= 7) {
    setCountStaffs(digitsOnly);
  }
}}
                />
              </Form.Group>
              <Form.Group as={Col} md={8} className="mb-3">
                <Form.Label className={formErrors.address ? "text-danger" : "text-dark"}>Address*</Form.Label>
                <Form.Control
                  type="text"
                
                  className="custom-input"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                />
              </Form.Group>
            </Row>
            <Row className="mb-4">
              <Form.Group as={Col} md={4} className="mb-3">
                <Form.Label className="text-dark">City</Form.Label>
                <Form.Control
                  type="text"
             
                  className="custom-input"
                  value={city}
                  onChange={(e) => {
  const value = e.target.value;
  const filteredValue = value.replace(/[0-9]/g, ''); // Remove digits
  setCity(filteredValue);
}}
                />
              </Form.Group>
              <Form.Group as={Col} md={4} className="mb-3">
                <Form.Label className={formErrors.state ? "text-danger" : "text-dark"}>State*</Form.Label>
                <Form.Control
                  type="text"
               
                  className="custom-input"
                  value={state}
                  onChange={(e) => {
  const value = e.target.value;
  const filteredValue = value.replace(/[0-9]/g, ''); // Remove digits
  setState(filteredValue);}}
                />
              </Form.Group>

              <Form.Group as={Col} md={4} className="mb-3">
                <Form.Label className={formErrors.pincode ? "text-danger" : "text-dark"}>Pincode*</Form.Label>
                <Form.Control
                  type="text"
             
                  className="custom-input"
                  value={pincode}
                  onChange={(e) => {
  const value = e.target.value;
  const digitsOnly = value.replace(/\D/g, ''); // Remove non-digits
  if (digitsOnly.length <= 6) {
    setPincode(digitsOnly);
  }
}}
                />
              </Form.Group>
            </Row>
            <Row className="mt-5">
              <Col md={12}>
                <h3 className="mb-4 add-organization-head3">Assign RM</h3>
              </Col>
            </Row>
            <Row className="mb-3">
              <Form.Group as={Col} md={4} className="mb-3">
                <Form.Label className="text-dark">RM Name</Form.Label>
                <Form.Control
                  type="text"
                 
                  className="custom-input"
                  value={RMname}
                    onChange={(e) => setRMname(e.target.value)}
                />
              </Form.Group>

              <Form.Group as={Col} md={4} className="mb-3">
                <Form.Label className="text-dark">RM ID</Form.Label>
                <Form.Control
                  type="text"
               
                  className="custom-input"
                  value={RMid}
                    onChange={(e) => setRMid(e.target.value)}
                />
              </Form.Group>
            </Row>

            <Row>
            <Col>   {errorMessage && <p className="text-danger fs-4 mt-3 mb-n4">{errorMessage}</p>}</Col>
              <Col className="text-end">
                <Button variant="primary" type="submit" className="savebtn" onClick={handleFormSubmit}>
                  Save
                </Button>
              </Col>
            </Row>
          </Form>
        </Row>
      </div>
    </div>
  );
};

export default AddOrganization;
