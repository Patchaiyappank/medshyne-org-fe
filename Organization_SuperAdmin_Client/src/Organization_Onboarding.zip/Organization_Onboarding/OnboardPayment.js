import React, { useState, useEffect } from 'react';
import '@fontsource/inter';
import { FaCheck } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Table } from 'react-bootstrap';
import './OnboardPayment.css';
import { useNavigate } from 'react-router-dom';
import image from './defimg.png';
import GenericPdfDownloader from './GenericPdfDownloader';

const ITEMS_PER_PAGE = 10;

const App = () => {
  const navigate = useNavigate();
  const [onboarding, setOnboarding] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    fetchOnboarding(); // Fetch data on component mount
  }, []);

    // const fetchOnboarding = async () => {
    //   try {
    //     const response = await fetch(`http://localhost:5000/superAdmin_onboarding_organizations`);
      
    //     const data = await response.json();
    //     if (response.ok) {
    //       setOnboarding(data.organizations);
    //     }
    //     else {
    //       throw new Error(data.message);
    //     }
    //   } catch (error) {
    //     console.error('Error fetching Onboarding_Organization:', error);
    //     // Handle error state or alert user
    //   }
    // };

    const fetchOnboarding = async () => {
      try {
        const response = await fetch(`http://localhost:5000/superAdmin_onboarding_organizations`);
        if (!response.ok) {
          const data = await response.json();
          throw new Error(data.message || 'Failed to fetch data');
        }
        const data = await response.json();
        setOnboarding(data.paid_details);
      } catch (error) {
        console.error('Error fetching Onboarding_Organization:', error.message || error);
        // Display an alert or set an error state to inform the user
        // e.g., setErrorState(true);
      }
    };
    

  const totalPages = Math.ceil(onboarding.length / ITEMS_PER_PAGE);
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const pagination_onboardpaymenting = onboarding.slice(startIndex, endIndex);

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPages) {
      setCurrentPage(newPage);
    }
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    const maxVisiblePages = 5;
    const ellipsis = "...";
    const totalPages = Math.ceil(onboarding.length / ITEMS_PER_PAGE);
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    if (startPage > 1) {
      pageNumbers.push(
        <span
          key={1}
          className={`onboardpagination-page ${
            currentPage === 1 ? "active" : ""
          }`}
          onClick={() => handlePageChange(1)}
        >
          {1}
        </span>
      );
      if (startPage > 2) {
        pageNumbers.push(<span key="ellipsisStart" className="ellipsis">{ellipsis}</span>);
      }
    }

    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(
        <span
          key={i}
          className={`onboardpagination-page ${
            currentPage === i ? "active" : ""
          }`}
          onClick={() => handlePageChange(i)}
        >
          {i}
        </span>
      );
    }

    if (endPage < totalPages) {
      if (endPage < totalPages - 1) {
        pageNumbers.push(<span key="ellipsisEnd" className="onboard-ellipsis">{ellipsis}</span>);
      }
      pageNumbers.push(
        <span
          key={totalPages}
          className={`onboardpagination-page ${
            currentPage === totalPages ? "active" : ""
          }`}
          onClick={() => handlePageChange(totalPages)}
        >
          {totalPages}
        </span>
      );
    }
    return pageNumbers;
  };



  return (
    <div className="container">
     
      <div style={{borderRadius: '20px' }} className="shadow-sm onboardpayment-table-container">
      

        <div className="mt-3 onboardpayment-table-container-innercell">
          <Table bordered={false} className="table-borderless onboardpayment-table-border" >
            <thead style={{ borderRadius: '20px'}}>
              <tr className='onboardpaymentingList-tableRow'>
                <th className='text-center'  style={{ color: '#667085', backgroundColor: '#FAFAFA' ,fontWeight:'400'}}>Invoice Number</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA' ,fontWeight:'400' }}>Date</th>
                <th className='text-center'  style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}>Status</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}>Customer</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}>Purchase</th>
                <th className='text-center' style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}>Invoice</th>
<th  style={{ color: '#667085', backgroundColor: '#FAFAFA',fontWeight:'400' }}></th>
              </tr>
            </thead>
            <tbody>
              {pagination_onboardpaymenting.map((onboardpaymenting, index) => (
                <tr key={index}>
                 
                  <td className='text-center onboardpaymenting-table-details' >{onboardpaymenting.invoice_number}</td>
                  <td className='text-center onboardpaymenting-table-details' >{onboardpaymenting.transaction_date}</td>
                  <td className='text-center onboardpaymenting-table-details'>
                  <span className="paid-status">
                  <FaCheck /> {onboardpaymenting.payment_status}
      </span></td>
                  <td className="align-middle">
                    <div className="d-flex align-items-center ">
                      <img
                        src={onboardpaymenting.profile ? onboardpaymenting.profile : image}
                        width={36}
                        alt="organization"
                        className="rounded-circle me-2"
                      />
                      <div>
                        <div className='onboardpaymenting-table-details'>{onboardpaymenting.organization_name}</div>
                        <div className="text-muted">{onboardpaymenting.organization_type}</div>
                      </div>
                    </div>
                  </td>
                  <td >
                    <div className='text-center onboardpaymenting-table-details'>{onboardpaymenting.plan_name}</div>
                  </td>
                  <td style={{ color: '#464E5F', fontSize: '14px', fontWeight: 'bold' }} >
                  <GenericPdfDownloader
                  rootElementId="pdfContent"
     
                  downloadFileName="Invoice"
               
                  invoiceDetails={onboardpaymenting.id}
                />
                  </td>
                </tr>
              ))}
            </tbody>
          </Table>
        </div>
      </div>
      <div className="onboard-pagination">
        <span className="onboard-pagination-arrow" onClick={() => handlePageChange(currentPage - 1)}>
          <span className="onboard-prevoius-arrow">&#8249;</span> Previous
        </span>
        <span className="onboard-pagination-pages">{renderPageNumbers()}</span>
        <span className="onboard-pagination-arrow" onClick={() => handlePageChange(currentPage + 1)}>
          Next <span className="onboard-next-arrow">&#8250;</span>
        </span>
      </div>
    </div>
  );
};

export default App;
